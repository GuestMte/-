import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from graphviz import Source
#Graphviz是一个开源的图形可视化软件，它可以将数据以图形的方式显示出来，通常用于绘制决策树、流程图、组织结构图等
from sklearn.tree import export_graphviz
import os
from sklearn.metrics import roc_curve #导入ROC曲线函数
import matplotlib.pyplot as plt #导入作图库
from sklearn.metrics import confusion_matrix #导入混淆矩阵函数
from sklearn.model_selection import StratifiedKFold
from sklearn import svm
from sklearn.neural_network import MLPClassifier

# #第一步，特征数值化
# #由于原始数据集数据有非数值型比如地址等等，因此需要对这些特征数值化，函数如下:
def quantification(dataPath,outputPath):
    df=pd.read_csv(dataPath)#使用pandas库读取位于dataPath路径下的CSV文件
    x=pd.factorize(df['Geography'])
    y=pd.factorize(df['Gender'])
    #使用pd.factorize()函数对Geography和Gender两列进行数值化处理。数值化是将分类标签（如字符串）转换为数值表示
    #pd.factorize()函数返回两个值：一个是数值处理后的数组，另一个是原始标签的数组。
    df['Geography']=x[0]
    df['Gender']=y[0]
    #我们使用了数值化后的数组（x[0]和y[0]）替代原来的分类标签数据
    df.to_csv(outputPath,index=True)#保存修改数据到新的地址,可通过index来决定是否保存索引到文件中
quantification("../data/Churn-Modelling-new.csv","../data/Churn-Modelling-newT.csv")#调用特征数值化函数，两个参数是原始数据地址和特征数值化后的地址

# #第二步:数据离散化处理
# #由于决策树需要的是离散型数据，而原本的数据集中比如年龄，收入等是连续型数据，因此如果想要处理，需要转化为离散型数据
# #具体如何离散化，每个特征列分为几等分根据实际情况判断，如下函数:
def discretization(dataPath,outputPath):
    df=pd.read_csv(dataPath)
    CreditScore=[];Age=[];Balance=[];EstimatedSalary=[];Exited=[];temp=[]
    # 信用分数划分成四等份，根据计算设置为:584,652,718
    for i in range(len(df)):
        if df["CreditScore"][i]<584:
            CreditScore.append(0)#赋值为 0
        elif df["CreditScore"][i]<652:
            CreditScore.append(1)#赋值为 1
        elif df["CreditScore"][i]<718:
            CreditScore.append(2)#赋值为 2
        else:
            CreditScore.append(3)#赋值为 3
    df["CreditScore"]=CreditScore #替代原数据
    #年龄
    for i in range(len(df)):
        if df["Age"][i]<=20:
            Age.append(0)
        elif df["Age"][i]<=40:
            Age.append(1)
        else:
            Age.append(2)
    df["Age"]=Age
    #存款情况,存款为0的单独列出来
    for i in range(len(df)):
        if (df["Balance"][i]!=0):
            temp.append(df["Balance"][i])
    temp.sort()
    q1=temp[len(temp)//4]#对一个列表（或其他类似的可索引对象）temp进行索引操作。这里的索引值是 len(temp) // 4，即列表长度的四分之一（向下取整）
    q2 = temp[len(temp) // 4*2]
    q3 = temp[len(temp) // 4*3]
    for i in range(len(df)):
        if df["Balance"][i]==0:
            Balance.append(0)
        elif df["Balance"][i]<q1:
            Balance.append(1)
        elif df["Balance"][i]<q2:
            Balance.append(2)
        elif df["Balance"][i]<q3:
            Balance.append(3)
        else:
            Balance.append(4)
    df["Balance"]=Balance
    temp.clear()
    #估计收入
    for i in range(len(df)):
        temp.append(df["EstimatedSalary"][i])
    temp.sort()
    q1=temp[len(temp)//4]#对一个列表（或其他类似的可索引对象）temp进行索引操作。这里的索引值是 len(temp) // 4，即列表长度的四分之一（向下取整）
    q2 = temp[len(temp) // 4*2]
    q3 = temp[len(temp) // 4*3]
    for i in range(len(df)):
        if df["EstimatedSalary"][i]<q1:
            EstimatedSalary.append(0)
        elif df["EstimatedSalary"][i]<q2:
            EstimatedSalary.append(1)
        elif df["EstimatedSalary"][i]<q3:
            EstimatedSalary.append(2)
        else:
            EstimatedSalary.append(3)
    df["EstimatedSalary"]=EstimatedSalary
    temp.clear()
    df.to_csv(outputPath,index=True)
discretization("../data/Churn-Modelling-newT.csv","../data/Churn-Modelling-new-tree.csv")#处理后保存文件位置
#
#
# #第三步：数据筛选
# #删除无用的特征列，比如编号等等，并筛选数据用欠采样解决类别不均衡问题，它从原始数据集中选取一定数量的样本，使得在输出的数据集中
# # 代码如下函数所示:
def filtering(dataPath, outputPath):
    df = pd.read_csv(dataPath)
    df_new = pd.DataFrame(
        columns=['Geography', 'EB', 'Age', 'EstimatedSalary', 'NumOfProducts', 'CreditScore', 'Tenure', 'HasCrCard','IsActiveMember', 'Exited', 'Gender'])
    ones = sum(df["Exited"])#只有0和1，因此是类别为1的数量，计算输入数据中流失客户的数量，即标签为 1 的样本数量
    length = len(df["EstimatedSalary"])# 计算输入数据中总的样本数量
    zeros = length - ones# 计算输入数据中未流失客户的数量，即标签为 0 的样本数量
    i = 0# 初始化一个循环变量，用于遍历输入数据的每一行
    flag_0 = 0
    flag_1 = 0
    # 初始化两个计数变量，用于记录输出数据中已经添加的流失和未流失客户的数量
    # 当循环变量小于总的样本数量时，执行循环
    while i != length:
        if df["Exited"][i] == 0 and flag_1 < ones:# 如果当前行的标签为 0，即未流失客户，且输出数据中已添加的未流失客户数量小于流失客户数量
            df_new = df_new.append(pd.DataFrame(
                {'Gender': df["Gender"][i], 'Geography': df["Geography"][i], 'EB': df["EB"][i], 'Age': df["Age"][i],'EstimatedSalary': df["EstimatedSalary"][i], 'NumOfProducts': df["NumOfProducts"][i],'CreditScore': df["CreditScore"][i], 'Tenure': df["Tenure"][i], 'HasCrCard': df["HasCrCard"][i],'IsActiveMember': df["IsActiveMember"][i], 'Exited': df["Exited"][i]}, index=[i]))
            # 将当前行的数据添加到输出数据中
            # 将输出数据中已添加的未流失客户数量加1
            flag_1 = flag_1 + 1
        # 如果当前行的标签为 1，即流失客户，且输出数据中已添加的流失客户数量小于未流失客户数量，具体步骤同上
        if df["Exited"][i] == 1 and flag_0 < zeros:
            df_new = df_new.append(pd.DataFrame(
                {'Gender': df["Gender"][i], 'Geography': df["Geography"][i], 'EB': df["EB"][i], 'Age': df["Age"][i],'EstimatedSalary': df["EstimatedSalary"][i], 'NumOfProducts': df["NumOfProducts"][i],'CreditScore': df["CreditScore"][i], 'Tenure': df["Tenure"][i], 'HasCrCard': df["HasCrCard"][i],'IsActiveMember': df["IsActiveMember"][i], 'Exited': df["Exited"][i]}, index=[i]))
            flag_0 = flag_0 + 1
        i = i + 1
    # 将输出数据保存为 csv 文件，路径为参数指定的输出路径
    df_new.to_csv(outputPath)
# 调用函数，传入输入数据和输出数据的路径
filtering("../data/Churn-Modelling-new-tree.csv","../data/final.csv")


# 划分训练集及测试集
csv=pd.read_csv("../data/final.csv")
csv_array=np.array(csv)
#print(csv.head())
#标签数据为array第11列 Exited
target=csv_array[:,10]
#第1列为编号，对决策树模型无意义，去除，将剩余列作为特征项
feature=csv_array[:,[1,2,3,4,5,6,7,8,9,11]]
#将数据集按4:1分为训练集和测试集
feature_train, feature_test, target_train, target_test = train_test_split(feature, target, test_size=0.2, random_state=10)
#使用train_test_split函数（通常来自sklearn.model_selection模块,因此要引入此包）将数据集分为训练集和测试集。
#test_size=0.2表示测试集占总数据集的20%，剩下的80%作为训练集。
#random_state=10是一个随机种子，确保每次运行代码时数据集的分割方式相同，使得实验结果可复现。
#feature_train和target_train将用于训练模型，而feature_test和target_test将用于评估模型的性能。

#开始数据建模
# 设置决策树参数
dt_model = DecisionTreeClassifier(criterion="gini",max_depth=6,min_samples_split=100)
#criterion="gini"：这是用来衡量划分质量的指标。"gini" 表示使用基尼不纯度（Gini impurity）作为划分标准。基尼不纯度是一个衡量集合中随机选中的样本被错误分类的概率的度量。它的值越小，表示集合的纯度越高。
#max_depth=6：这是树的最大深度。当树的深度达到这个值时，树的生长就会停止。限制树的最大深度可以避免过拟合，即模型在训练数据上表现很好，但在未知数据上表现不佳
#min_samples_split=200：这是一个节点在被考虑分裂之前必须具有的最小样本数。如果某个节点的样本数少于这个值，则该节点不会被进一步分裂。这个参数同样可以帮助控制过拟合，因为它防止了模型学习训练数据中的噪声或异常值
dt_model.fit(feature_train,target_train)#导入数据，训练模型
scores = dt_model.score(feature_test,target_test)#测试模型准确度
print(scores)
predict_results = dt_model.predict(feature_test)#测试集根据决策树的预测结果，在已经用数据训练好模型后
print(predict_results)#预测的结果

#创建流程图保存路径
image_path = "../images/decision_trees"
# os.makedirs(image_path, exist_ok=True)

export_graphviz(dt_model,
                out_file=os.path.join(image_path, "bank_tree.dot"),
                feature_names=["Geography", "EB", "Age", "EstimatedSalary", "NumOfProducts", "CreditScore", "Tenure",
                               "HasCrCard", "IsActiveMember", "Gender"],
                class_names=["not exited", "exited"],
                rounded=True,
                filled=True)
#export_graphviz 调用 export_graphviz 函数，该函数用于将训练好的决策树模型 dt_model 导出为 Graphviz 的 DOT 格式
#DOT 格式是一种文本文件格式，用于描述图形结构，可以被 Graphviz 工具读取并渲染成可视化的图形
# dt_model 为训练好的模型
#out_file 指定了导出的DOT文件的保存路径和文件名。
#os.path.join 函数用于拼接目录和文件名，确保在不同操作系统下都能正确生成文件路径。bank_tree.dot 是将要保存的 DOT 文件的名称
#class_names参数 用来确定分类名称
#feature_name参数 指定了决策树中用到的特征名称列表。这些名称将在生成的图形中用于标记每个节点的特征。
#rounded=True 这个参数指定生成的图形中的节点应该是圆角矩形的
#filled=True 这个参数指定生成的图形中的节点应该被填充颜色。通常，节点的颜色会根据其所属的类别进行着色，以便于区分。
s = Source.from_file(os.path.join(image_path, "bank_tree.dot"))
# #这行代码使用 Graphviz 的 Source 类从刚才保存的 DOT 文件创建一个源对象 s。这个对象可以用来进一步操作或渲染图形
# #默认输出为pdf文件，不过也可以设置输出为图片 如.png 等其他格式
s.view()



#绘制ROC曲线 可用来评估模型分类性能
# 绘制的图片曲线下面积越大，代表准确度越高
fpr, tpr, thresholds = roc_curve(target_test, predict_results, pos_label=1)
#使用roc_curve函数从sklearn.metrics库计算ROC曲线的各个点。
#target_test是真实的目标标签（通常是二进制的，例如0和1）。
#predict_results是模型预测的标签结果
#pos_label=1指定正类标签的值为1。
# 函数返回三个值：
# fpr：假正类率（False Positive Rate）tpr：真正类率（True Positive Rate）thresholds：用于计算上述率的阈值
plt.figure(figsize=(10,10))
plt.plot(fpr, tpr, linewidth=2, label = 'ROC curve') #作出ROC曲线
plt.plot([0,1],[0,1],'k--',label='guess')
plt.title("ROC Curve",fontsize=25)
plt.xlabel('False Positive Rate',fontsize=20) #坐标轴标签
plt.ylabel('True Positive Rate',fontsize=20) #坐标轴标签
plt.ylim(0,1.05) #边界范围
plt.xlim(0,1.05) #边界范围
plt.legend(loc=4,fontsize=20) #图例
plt.show() #显示作图结果


#混淆矩阵
cm = confusion_matrix(target_test, predict_results)  # 计算混淆矩阵
plt.figure(figsize=(10, 10))
plt.matshow(cm, fignum=0, cmap=plt.cm.Blues)#plt.cm.Blues是matplotlib中的一个预定义色彩映射，它使用不同深浅的蓝色来表示不同的值
plt.colorbar()  # 颜色标签
for x in range(len(cm)):  # 数据标签
    for y in range(len(cm)):
        plt.annotate(cm[x, y], xy=(x, y), fontsize=30, horizontalalignment='center', verticalalignment='center')
#cm[x, y]: 这是你想要在图上标注的文本内容。在混淆矩阵的上下文中，cm[x, y]表示混淆矩阵中位于第x行第y列的元素值，通常代表实际类别为y而被预测为x的样本数量
#xy=(x, y): 这个参数定义了文本标注的位置。在混淆矩阵的情境中，xy=(x, y)指的是矩阵中第x行第y列单元格的中心位置，这里x和y是矩阵的索引。
#fontsize=30: 这个参数指定了标注文本的大小，单位是点（pt）。在这个例子中，文本大小被设置为30，你可以根据需要调整这个值。
#forizontalalignment='center': 这个参数定义了文本在水平方向上的对齐方式。'center'意味着文本会在其指定的xy坐标位置上水平居中显示。
#verticalalignment='center': 这个参数定义了文本在垂直方向上的对齐方式。'center'意味着文本会在其指定的xy坐标位置上垂直居中显示。
#混淆矩阵上的4个数字，从左到右，从上到下依次是真正例，假正例，真反例，假反例的数量
plt.ylabel('Hypothesized class', fontsize=20)  # 坐标轴标签
plt.xlabel('True class', fontsize=20)  # 坐标轴标签
plt.show()


# 10折交叉验证
skfold = StratifiedKFold(n_splits=10,shuffle=False)#10折交叉验证
x_axis=[] ; y_axis=[]
k=0;max=0;min=100;sum=0
for train_index,test_index in skfold.split(feature,target):#返回的是索引，分别为测试数据索引和训练数据索引
    k+=1
    skfold_feature_train=feature[train_index]
    skfold_feature_test=feature[test_index]
    skfold_target_train=target[train_index]
    skfold_target_test=target[test_index]
    dt_model.fit(skfold_feature_train,skfold_target_train)#训练数据训练模型
    scores = dt_model.score(skfold_feature_test,skfold_target_test)#通过训练数据训练的模型测试准确率
    x_axis.append(k)
    y_axis.append(scores)
    if scores>max:
        max=scores
    if scores<min:
        min=scores
    sum+=scores
avg=sum/k
plt.plot(x_axis,y_axis)
plt.ylim(0.6,0.9)
plt.xlim(1,10)
plt.xlabel("Rounds")
plt.ylabel('True Rate')
plt.title("KFold Cross Validation (k=%s) avg=%s"%(k,round(avg*100,2))+"%"+" max:"+"%s"%(round(max*100,2))+"%"+" min:"+"%s"%(round(min*100,2))+"%")
plt.show()

#5折交叉验证
skfold_5 = StratifiedKFold(n_splits=5,shuffle=False)

x_axis_5=[] ; y_axis_5=[]
k_5=0;max_5=0;min_5=100;sum_5=0
for train_index,test_index in skfold_5.split(feature,target):
    k_5+=1
    skfold_feature_train=feature[train_index]
    skfold_feature_test=feature[test_index]
    skfold_target_train=target[train_index]
    skfold_target_test=target[test_index]
    dt_model.fit(skfold_feature_train,skfold_target_train)
    scores = dt_model.score(skfold_feature_test,skfold_target_test)
    x_axis_5.append(k_5)
    y_axis_5.append(scores)
    if scores>max_5:
        max_5=scores
    if scores<min_5:
        min_5=scores
    sum_5+=scores
avg_5=sum_5/k_5

plt.plot(x_axis_5,y_axis_5)
plt.ylim(0.6,0.9)
plt.xlim(1,5)
plt.xlabel("Rounds")
plt.ylabel('True Rate')
plt.title("KFold Cross Validation (k=%s) avg=%s"%(k_5,round(avg_5*100,2))+"%"+" max:"+"%s"%(round(max_5*100,2))+"%"+" min:"+"%s"%(round(min_5*100,2))+"%")
plt.show()

#15折交叉验证
skfold_15 = StratifiedKFold(n_splits=15,shuffle=False)

x_axis=[] ; y_axis=[]
k=0;max=0;min=100;sum=0
for train_index,test_index in skfold_15.split(feature,target):
    k+=1
    skfold_feature_train=feature[train_index]
    skfold_feature_test=feature[test_index]
    skfold_target_train=target[train_index]
    skfold_target_test=target[test_index]
    dt_model.fit(skfold_feature_train,skfold_target_train)
    scores = dt_model.score(skfold_feature_test,skfold_target_test)
    x_axis.append(k)
    y_axis.append(scores)
    if scores>max:
        max=scores
    if scores<min:
        min=scores
    sum+=scores
avg=sum/k

plt.plot(x_axis,y_axis)
plt.ylim(0.6,0.9)
plt.xlim(1,15)
plt.xlabel("Rounds")
plt.ylabel('True Rate')
plt.title("KFold Cross Validation (k=%s) avg=%s"%(k,round(avg*100,2))+"%"+" max:"+"%s"%(round(max*100,2))+"%"+" min:"+"%s"%(round(min*100,2))+"%")
plt.show()


#使用SVM进行分类
clf=svm.SVC()#创建一个支持向量机（Support Vector Machine, SVM）分类器的实例
clf.fit(feature_train,target_train)
clf.predict(feature_test)

#%%

scores_svm = clf.score(feature_test,target_test)
print(scores_svm)#支撑向量机的准确率

cm = confusion_matrix(target_test, clf.predict(feature_test))  # 混淆矩阵

plt.figure(figsize=(10, 10))
plt.matshow(cm, fignum=0, cmap=plt.cm.Blues)
plt.colorbar()  # 颜色标签
for x in range(len(cm)):  # 数据标签
    for y in range(len(cm)):
        plt.annotate(cm[x, y], xy=(x, y), fontsize=30, horizontalalignment='center', verticalalignment='center')

plt.ylabel('Hypothesized class', fontsize=20)  # 坐标轴标签
plt.xlabel('True class', fontsize=20)  # 坐标轴标签
plt.show()

# 使用MLP(多层感知机)神经网络进行分类
mlp = MLPClassifier(solver='lbfgs', alpha=1e-5,hidden_layer_sizes=(10, 11),max_iter=10000, random_state=1)
#创建一个MLPClassifier的实例
# solver='lbfgs': 指定优化算法为'lbfgs'。'lbfgs'是一种优化算法，用于找到损失函数的最小值。
# alpha=1e-5: L2惩罚（正则化项）的参数。
# hidden_layer_sizes=(10, 11): 指定隐藏层的神经元数量。这里有两层隐藏层，第一层有10个神经元，第二层有11个神经元。
# random_state=1: 随机数生成器的种子，确保每次运行代码时得到的结果是可复现的。
mlp.fit(feature_train,target_train)#使用训练数据feature_train和对应的标签target_train来训练多层感知机分类器。
mlp.predict(feature_test)#使用训练好的模型进行预测
scores_mlp = mlp.score(feature_test,target_test)#计算准确率
print(scores_mlp)#输出算法准确率

cm = confusion_matrix(target_test, mlp.predict(feature_test))  # 混淆矩阵

plt.figure(figsize=(10, 10))
plt.matshow(cm, fignum=0, cmap=plt.cm.Blues)
plt.colorbar()  # 颜色标签
for x in range(len(cm)):  # 数据标签
    for y in range(len(cm)):
        plt.annotate(cm[x, y], xy=(x, y), fontsize=30, horizontalalignment='center', verticalalignment='center')

plt.ylabel('Hypothesized class', fontsize=20)  # 坐标轴标签
plt.xlabel('True class', fontsize=20)  # 坐标轴标签
plt.show()